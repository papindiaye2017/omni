<?php
/**
 * Load 3rd party compatibility tweaks.
 */
require_once( JOB_MANAGER_PLUGIN_DIR . '/includes/3rd-party/wpml.php' );
require_once( JOB_MANAGER_PLUGIN_DIR . '/includes/3rd-party/polylang.php' );
