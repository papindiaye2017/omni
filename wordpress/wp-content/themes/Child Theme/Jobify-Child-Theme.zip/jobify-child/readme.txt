# Jobify Child Theme

Add custom CSS to style.css and custom PHP functionality to functions.php